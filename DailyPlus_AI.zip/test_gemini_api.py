"""Test script to verify Gemini API key functionality."""
from langchain_google_genai import ChatGoogleGenerativeAI
from config.settings import settings

def test_gemini_api():
    """Test the Gemini API key with a simple prompt."""
    # Models to try in order
    models_to_try = [
        "gemini-1.5-flash",
        "gemini-1.5-pro",
        "gemini-pro",
        "gemini-1.0-pro"
    ]
    
    
    for model_name in models_to_try:
        try:
            print(f"Testing with model: {model_name}")
            
            # Initialize the LLM
            llm = ChatGoogleGenerativeAI(
                model=model_name,
                temperature=0.2,
                google_api_key=settings.GEMINI_API_KEY
            )
            
            # Make a test call
            response = llm.invoke("Say 'API key working'")
            
            # Print success message (using ASCII characters for Windows compatibility)
            print(f"[SUCCESS] API Response: {response.content}")
            print(f"\n[SUCCESS] Gemini API key valid and responding correctly with model: {model_name}")
            return True
            
        except Exception as e:
            error_type = type(e).__name__
            error_msg = str(e)
            
            # Check for authentication errors
            if "authentication" in error_msg.lower() or "api key" in error_msg.lower() or "401" in error_msg:
                print(f"[FAILED] API key invalid or expired")
                print(f"Error details: {error_type}: {error_msg}")
                return False
            elif "404" in error_msg or "not found" in error_msg.lower():
                print(f"[INFO] Model {model_name} not available, trying next...")
                continue
            else:
                print(f"[FAILED] API key test failed with {model_name}: {error_type}: {error_msg}")
                continue
    
    print("\n[FAILED] All model attempts failed. API key may be invalid or all models unavailable.")
    return False

if __name__ == "__main__":
    test_gemini_api()

# Made with Bob
