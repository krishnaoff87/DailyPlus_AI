"""AI processor with LangChain + Gemini and strict Pydantic schemas."""

import json
import re
from typing import Literal

import streamlit as st
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
from pydantic import BaseModel

from config.settings import settings
from src.ingest.loader import MockContextItem
from src.ingest.sanitizer import LocalSanitizer


class ActionItem(BaseModel):
    """Pydantic model for action items extracted from daily context."""

    task: str
    assignee: str
    deadline: str | None
    priority: Literal["urgent", "high", "medium", "low"]


class DailyBriefing(BaseModel):
    """Pydantic model for daily briefing with summary, actions, and stakeholders."""

    summary: str
    actions: list[ActionItem]
    stakeholders: list[str]


def _rule_based_fallback(items: list[MockContextItem]) -> DailyBriefing:
    """
    Deterministic fallback extraction using keyword/regex patterns.
    
    Args:
        items: List of validated MockContextItem objects
    
    Returns:
        DailyBriefing: Basic briefing extracted using deterministic rules
    """
    # Extract summary bullets from subjects
    summary_bullets = []
    for item in items[:3]:  # Top 3 items
        summary_bullets.append(f"• {item.subject}")
    summary = "\n".join(summary_bullets)
    
    # Extract actions from items marked with has_action=True
    actions = []
    for item in items:
        if item.has_action:
            # Extract assignee from participants or sender
            assignee = item.participants[0] if item.participants else item.sender
            
            # Map urgency_hint to priority with proper typing
            urgency_lower = item.urgency_hint.lower()
            if urgency_lower == "urgent":
                priority: Literal["urgent", "high", "medium", "low"] = "urgent"
            elif urgency_lower == "high":
                priority = "high"
            elif urgency_lower == "low":
                priority = "low"
            else:
                priority = "medium"
            
            # Extract deadline using regex (look for date patterns)
            deadline = None
            date_pattern = r'\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{4}|today|tomorrow|next week'
            match = re.search(date_pattern, item.body, re.IGNORECASE)
            if match:
                deadline = match.group(0)
            
            actions.append(ActionItem(
                task=item.subject,
                assignee=assignee,
                deadline=deadline,
                priority=priority
            ))
    
    # Extract unique stakeholders from all participants and senders
    stakeholders = set()
    for item in items:
        stakeholders.add(item.sender)
        stakeholders.update(item.participants)
    
    return DailyBriefing(
        summary=summary,
        actions=actions,
        stakeholders=sorted(list(stakeholders))
    )


def process_daily_context(items: list[MockContextItem]) -> DailyBriefing:
    """
    Process daily context items using Gemini AI to extract briefing information.
    
    Implements a complete triage and sanitization pipeline:
    1. Pre-filtering triage to skip non-actionable items without priority keywords
    2. Token savings calculation and audit tracking
    3. PII sanitization before LLM processing
    4. LLM-based extraction with retry logic
    5. PII restoration after LLM processing

    Args:
        items: List of validated MockContextItem objects

    Returns:
        DailyBriefing: Validated briefing with summary, actions, and stakeholders

    Raises:
        ValueError: If API key is missing or AI response is invalid after retries
    """
    # Triage: Filter out non-actionable items without priority keywords
    PRIORITY_KEYWORDS = ["urgent", "deadline", "review", "due"]
    skipped_items = []
    actionable_items = []
    skipped_count = 0
    
    for item in items:
        combined_text = (item.subject + " " + item.body).lower()
        has_priority_keyword = any(keyword in combined_text for keyword in PRIORITY_KEYWORDS)
        
        if item.has_action == False and not has_priority_keyword:
            skipped_items.append(item)
            skipped_count += 1
        else:
            actionable_items.append(item)
    
    # Audit: Track token savings from pre-filtering
    tokens_saved = skipped_count * 150
    st.session_state.tokens_saved = tokens_saved
    
    # Optimization: Bypass LLM if no actionable items remain after triage
    if len(actionable_items) == 0:
        return _rule_based_fallback(items)
    
    # Sanitization: Mask PII before sending to LLM
    sanitizer = LocalSanitizer()
    
    # Initialize Gemini with JSON response mode
    # Using gemini-2.5-flash as it's available in the current API
    llm = ChatGoogleGenerativeAI(
        model="gemini-2.5-flash",
        google_api_key=settings.GEMINI_API_KEY,
        temperature=0.2,
        response_mime_type="application/json"
    )

    # Create Pydantic output parser
    parser = PydanticOutputParser(pydantic_object=DailyBriefing)

    # Format items for the prompt with sanitized content
    items_text = "\n\n".join(
        [
            f"Item {idx + 1}:\n"
            f"Source: {item.source}\n"
            f"Timestamp: {item.timestamp}\n"
            f"Subject: {sanitizer.mask_text(item.subject)}\n"
            f"Body: {sanitizer.mask_text(item.body)}\n"
            f"Sender: {sanitizer.mask_text(item.sender)}\n"
            f"Participants: {', '.join(sanitizer.mask_text(p) for p in item.participants)}\n"
            f"Urgency: {item.urgency_hint}\n"
            f"Has Action: {item.has_action}"
            for idx, item in enumerate(actionable_items)
        ]
    )

    # Create prompt template
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are an AI assistant that extracts structured information from work items. Return ONLY valid JSON."),
        ("human", """Analyze these work items and extract:
1. A 3-bullet summary of the day
2. All actionable items with task, assignee, deadline, priority
3. List of all stakeholders mentioned

Work Items:
{items_text}""")
    ])

    # Create the chain: prompt | llm | parser
    chain = prompt | llm | parser

    # Retry logic: max 2 attempts
    max_attempts = 2
    last_error = None

    for attempt in range(max_attempts):
        try:
            # Invoke the chain
            briefing = chain.invoke({
                "items_text": items_text
            })

            # Sanitization: Restore original values after LLM processing
            briefing.summary = sanitizer.unmask_text(briefing.summary)
            for action in briefing.actions:
                action.task = sanitizer.unmask_text(action.task)
                action.assignee = sanitizer.unmask_text(action.assignee)
            briefing.stakeholders = [sanitizer.unmask_text(s) for s in briefing.stakeholders]

            return briefing

        except json.JSONDecodeError as e:
            last_error = f"JSON parsing error on attempt {attempt + 1}: {e}"
        except Exception as e:
            last_error = f"Validation error on attempt {attempt + 1}: {e}"

    # If all attempts failed, use fallback extraction
    return _rule_based_fallback(items)


__all__ = ["ActionItem", "DailyBriefing", "process_daily_context"]

# Made with Bob
