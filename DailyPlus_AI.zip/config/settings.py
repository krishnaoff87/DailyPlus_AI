"""
Secure configuration loader for DailyPlus_AI PoC.
Validates environment variables at boot time.
"""

from pathlib import Path
from dotenv import load_dotenv
from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings with Pydantic validation."""

    GEMINI_API_KEY: str
    ENVIRONMENT: str = "development"
    MOCK_DATA_PATH: str = "data/mock_daily_context.json"
    STREAMLIT_SERVER_PORT: int = 8501

    model_config = SettingsConfigDict(
        env_file="config/.env", env_file_encoding="utf-8", extra="ignore"
    )

    @field_validator("GEMINI_API_KEY")
    @classmethod
    def validate_gemini_key(cls, v: str) -> str:
        """Validate that GEMINI_API_KEY starts with 'AIza'."""
        if not v.startswith("AIza"):
            raise ValueError(
                "Invalid GEMINI_API_KEY format!\n\n"
                "The API key must start with 'AIza'.\n"
                "Get your API key from: https://aistudio.google.com/app/apikey"
            )
        return v

    @classmethod
    def validate_settings(cls) -> None:
        """Validate settings and halt boot if invalid."""
        try:
            # Load .env file from config directory
            config_dir = Path(__file__).parent.resolve()
            env_path = config_dir / ".env"
            load_dotenv(dotenv_path=env_path)
            cls()
        except Exception as e:
            raise SystemExit(
                f"❌ CONFIGURATION ERROR:\n{str(e)}\n\n"
                "Setup Instructions:\n"
                "1. Copy 'config/.env.example' to 'config/.env'\n"
                "2. Add your Gemini API key to 'config/.env'\n"
                "3. Ensure the key starts with 'AIza'\n"
                "4. Get your API key from: https://aistudio.google.com/app/apikey"
            ) from e


# Load .env file from config directory
config_dir = Path(__file__).parent.resolve()
env_path = config_dir / ".env"

load_dotenv(dotenv_path=env_path)

# Create settings instance
try:
    settings = Settings()
except Exception as e:
    raise ValueError(
        "GEMINI_API_KEY is missing or invalid!\n\n"
        "Setup Instructions:\n"
        "1. Copy 'config/.env.example' to 'config/.env'\n"
        "2. Add your Gemini API key to 'config/.env'\n"
        "3. Ensure the key starts with 'AIza'\n"
        "4. Get your API key from: https://aistudio.google.com/app/apikey"
    ) from e

# Export settings instance
__all__ = ["settings", "Settings"]

# Made with Bob
